#!/bin/bash
# AgentMint Evidence Verification — RFC 3161 Timestamps
# Requires: openssl
# For Ed25519 signatures: python3 verify_sigs.py

set -euo pipefail
cd "$(dirname "$0")"

VERIFIED=0
FAILED=0
FLAGGED=0
TOTAL=0

echo "── Receipt eb7b3394 ──"
echo "  Action:    tool:book_new_flight"
echo "  Agent:     cs-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:28:32.275585+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 47ccacc0 ──"
echo "  Action:    tool:get_flight_status"
echo "  Agent:     cs-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:28:32.276122+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 1b5f0b51 ──"
echo "  Action:    tool:cancel_flight"
echo "  Agent:     cs-agent"
echo "  In Policy: False"
echo "  Observed:  2026-04-08T16:28:32.276378+00:00"
echo "  ⚠ FLAGGED: matched checkpoint tool:cancel_flight"
FLAGGED=$((FLAGGED + 1))
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt f14f4d5d ──"
echo "  Action:    tool:send_customer_email"
echo "  Agent:     cs-agent"
echo "  In Policy: False"
echo "  Observed:  2026-04-08T16:28:32.276663+00:00"
echo "  ⚠ FLAGGED: matched checkpoint tool:send_customer_email"
FLAGGED=$((FLAGGED + 1))
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "════════════════════════════════════════"
echo "  Timestamps: $VERIFIED / $TOTAL verified"
echo "  Failures:   $FAILED"
echo "  Flagged:    $FLAGGED out-of-policy"
echo "  Signatures: run python3 verify_sigs.py"
echo "════════════════════════════════════════"

[ "$FAILED" -gt 0 ] && exit 1
exit 0
