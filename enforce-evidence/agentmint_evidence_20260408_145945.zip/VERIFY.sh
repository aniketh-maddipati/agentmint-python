#!/bin/bash
# AgentMint Evidence Verification — RFC 3161 Timestamps
# Requires: openssl
# For Ed25519 signatures: python3 verify_sigs.py

set -euo pipefail
cd "$(dirname "$0")"

VERIFIED=0
FAILED=0
FLAGGED=0
TOTAL=0

echo "── Receipt 645e50c1 ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T14:59:45.592383+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 7f1b5bf7 ──"
echo "  Action:    tool:fetch_config"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T14:59:45.592826+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 70ef268e ──"
echo "  Action:    tool:search_web"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T14:59:45.593182+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt d9646a7b ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T14:59:45.593444+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 5a770be7 ──"
echo "  Action:    tool:delete_all_users"
echo "  Agent:     billing-agent"
echo "  In Policy: False"
echo "  Observed:  2026-04-08T14:59:45.593623+00:00"
echo "  ⚠ FLAGGED: no scope pattern matched"
FLAGGED=$((FLAGGED + 1))
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt ecf858ea ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T14:59:45.593857+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "════════════════════════════════════════"
echo "  Timestamps: $VERIFIED / $TOTAL verified"
echo "  Failures:   $FAILED"
echo "  Flagged:    $FLAGGED out-of-policy"
echo "  Signatures: run python3 verify_sigs.py"
echo "════════════════════════════════════════"

[ "$FAILED" -gt 0 ] && exit 1
exit 0
