#!/bin/bash
# AgentMint Evidence Verification — RFC 3161 Timestamps
# Requires: openssl
# For Ed25519 signatures: python3 verify_sigs.py

set -euo pipefail
cd "$(dirname "$0")"

VERIFIED=0
FAILED=0
FLAGGED=0
TOTAL=0

echo "── Receipt e2272e01 ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:05.271132+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 1757bfe3 ──"
echo "  Action:    tool:fetch_config"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:05.271629+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt b1e23b79 ──"
echo "  Action:    tool:search_web"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:05.271995+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt b207835d ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:05.272255+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 9acb8c6b ──"
echo "  Action:    tool:delete_all_users"
echo "  Agent:     billing-agent"
echo "  In Policy: False"
echo "  Observed:  2026-04-08T16:44:05.272439+00:00"
echo "  ⚠ FLAGGED: no scope pattern matched"
FLAGGED=$((FLAGGED + 1))
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 63d532cf ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:05.272675+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "════════════════════════════════════════"
echo "  Timestamps: $VERIFIED / $TOTAL verified"
echo "  Failures:   $FAILED"
echo "  Flagged:    $FLAGGED out-of-policy"
echo "  Signatures: run python3 verify_sigs.py"
echo "════════════════════════════════════════"

[ "$FAILED" -gt 0 ] && exit 1
exit 0
