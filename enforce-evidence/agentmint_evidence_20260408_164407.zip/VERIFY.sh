#!/bin/bash
# AgentMint Evidence Verification — RFC 3161 Timestamps
# Requires: openssl
# For Ed25519 signatures: python3 verify_sigs.py

set -euo pipefail
cd "$(dirname "$0")"

VERIFIED=0
FAILED=0
FLAGGED=0
TOTAL=0

echo "── Receipt e93a9951 ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:07.403104+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 710edbed ──"
echo "  Action:    tool:fetch_config"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:07.403573+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt c74ab00f ──"
echo "  Action:    tool:search_web"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:07.403945+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt c0a4aa75 ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:07.404219+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt f0e0a5a9 ──"
echo "  Action:    tool:delete_all_users"
echo "  Agent:     billing-agent"
echo "  In Policy: False"
echo "  Observed:  2026-04-08T16:44:07.404421+00:00"
echo "  ⚠ FLAGGED: no scope pattern matched"
FLAGGED=$((FLAGGED + 1))
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 26036e94 ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:07.404672+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "════════════════════════════════════════"
echo "  Timestamps: $VERIFIED / $TOTAL verified"
echo "  Failures:   $FAILED"
echo "  Flagged:    $FLAGGED out-of-policy"
echo "  Signatures: run python3 verify_sigs.py"
echo "════════════════════════════════════════"

[ "$FAILED" -gt 0 ] && exit 1
exit 0
