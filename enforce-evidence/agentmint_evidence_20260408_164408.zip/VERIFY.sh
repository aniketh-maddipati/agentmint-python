#!/bin/bash
# AgentMint Evidence Verification — RFC 3161 Timestamps
# Requires: openssl
# For Ed25519 signatures: python3 verify_sigs.py

set -euo pipefail
cd "$(dirname "$0")"

VERIFIED=0
FAILED=0
FLAGGED=0
TOTAL=0

echo "── Receipt 3efec179 ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:08.492697+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 3220172d ──"
echo "  Action:    tool:fetch_config"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:08.493298+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt a85b12fb ──"
echo "  Action:    tool:search_web"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:08.493728+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt fe602fd7 ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:08.494016+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt a7cea7a5 ──"
echo "  Action:    tool:delete_all_users"
echo "  Agent:     billing-agent"
echo "  In Policy: False"
echo "  Observed:  2026-04-08T16:44:08.494313+00:00"
echo "  ⚠ FLAGGED: no scope pattern matched"
FLAGGED=$((FLAGGED + 1))
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt cbde85d3 ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:08.494638+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "════════════════════════════════════════"
echo "  Timestamps: $VERIFIED / $TOTAL verified"
echo "  Failures:   $FAILED"
echo "  Flagged:    $FLAGGED out-of-policy"
echo "  Signatures: run python3 verify_sigs.py"
echo "════════════════════════════════════════"

[ "$FAILED" -gt 0 ] && exit 1
exit 0
