#!/bin/bash
# AgentMint Evidence Verification — RFC 3161 Timestamps
# Requires: openssl
# For Ed25519 signatures: python3 verify_sigs.py

set -euo pipefail
cd "$(dirname "$0")"

VERIFIED=0
FAILED=0
FLAGGED=0
TOTAL=0

echo "── Receipt 9428c1b8 ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:06.348240+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 072f5ecc ──"
echo "  Action:    tool:fetch_config"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:06.348732+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 2f04061c ──"
echo "  Action:    tool:search_web"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:06.349119+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 54837a3f ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:06.349389+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt 5d7a06d6 ──"
echo "  Action:    tool:delete_all_users"
echo "  Agent:     billing-agent"
echo "  In Policy: False"
echo "  Observed:  2026-04-08T16:44:06.349583+00:00"
echo "  ⚠ FLAGGED: no scope pattern matched"
FLAGGED=$((FLAGGED + 1))
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "── Receipt a87e1f2c ──"
echo "  Action:    tool:send_email"
echo "  Agent:     billing-agent"
echo "  In Policy: True"
echo "  Observed:  2026-04-08T16:44:06.349851+00:00"
echo "  Timestamp: (not requested)"
TOTAL=$((TOTAL + 1))
echo ""
echo "════════════════════════════════════════"
echo "  Timestamps: $VERIFIED / $TOTAL verified"
echo "  Failures:   $FAILED"
echo "  Flagged:    $FLAGGED out-of-policy"
echo "  Signatures: run python3 verify_sigs.py"
echo "════════════════════════════════════════"

[ "$FAILED" -gt 0 ] && exit 1
exit 0
